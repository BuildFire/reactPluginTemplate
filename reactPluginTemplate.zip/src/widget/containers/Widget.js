import React from 'react';
import { hot } from 'react-hot-loader/root';

const Widget = () => (
  <h1>Widget - Hello World!</h1>
);

export default hot(Widget);
