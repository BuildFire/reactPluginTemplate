
#### the Resources (folder)
The Resources is the default images which will be used for your widget .
* image.png : this image file will be used as a default image for your widget which will appear when App Owners installed your plugin in their plugin Manager .

* icon.png : this image file will be used as a default icon for your widget which will appear as an icon for the widget on the emulator and the actual device .

 * **Note** :This folder is only meant for plugin configuration resource like default widget icon and widget hero image.** You can replace those two files if you need by overriding the default hero image and default icon image. **Don't add any other files in this folder, any dependencies in this folder WILL NOT be carried over to the app.**


