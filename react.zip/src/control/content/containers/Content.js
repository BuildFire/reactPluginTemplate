import React from "react";
import { hot } from "react-hot-loader/root";
import Home from "../Components/Home/Home";
const Content = () => {
  return (
    <>
      <Home />
    </>
  );
};

export default hot(Content);
