import React from 'react';
import { hot } from 'react-hot-loader/root';

const Design = () => (
  <h1>Design - Hello World!</h1>
);

export default hot(Design);
