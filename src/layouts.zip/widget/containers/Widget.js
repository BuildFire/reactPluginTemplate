import React from 'react'
import LayoutManager from '../shared/LayoutManager';

export default function Widget() {
  return (
    <>
    <LayoutManager/>
    </>
  )
}

