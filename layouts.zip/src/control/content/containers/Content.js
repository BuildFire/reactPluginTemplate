import React from "react";
import { hot } from "react-hot-loader/root";
import LayoutHeader from "../shared/LayoutHeader";

const Content = () => {
  return (
    <>
      <LayoutHeader />
    </>
  );
};

export default hot(Content);
